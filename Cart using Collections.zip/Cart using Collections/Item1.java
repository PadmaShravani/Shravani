package collection.file.io;

public class Item1 {

		private String itemName;
		private Double itemPrice;
		private int itemqty;
		
		
		/**
		 * @return the itemName
		 */
		public String getItemName() {
			return itemName;
		}
		/**
		 * @param itemName the itemName to set
		 */
		public void setItemName(String itemName) {
			this.itemName = itemName;
		}
		/**
		 * @return the itemPrice
		 */
		public Double getItemPrice() {
			return itemPrice;
		}
		/**
		 * @param itemPrice the itemPrice to set
		 */
		public void setItemPrice(Double itemPrice) {
			this.itemPrice = itemPrice;
		}
		/**
		 * @return the itemqty
		 */
		public int getItemqty() {
			return itemqty;
		}
		/**
		 * @param itemqty the itemqty to set
		 */
		public void setItemqty(int itemqty) {
			this.itemqty = itemqty;
		}
		
		
	}



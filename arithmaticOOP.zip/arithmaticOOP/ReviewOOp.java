package org.persholas.reviewproject.week11;

public class ReviewOOp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArithameticOperations ao=new ArithameticOperations();
		ao.input();
		System.out.println("Addition is "+ao.add());
		System.out.println("Substraction is "+ao.sub());
		System.out.println("Multiplication is "+ao.mul());
		ao.div();
		
	}

}

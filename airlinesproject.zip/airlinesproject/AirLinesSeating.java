package airlinesproject;

import java.util.HashMap;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AirLinesSeating {
	//fields 
	private Scanner input;
	private String bookedSeatNumbers;
	private HashMap<String, Integer> alphabet;// to store alpha as key
	private String[][] planeSeats = new String[26][10]; // create 2D array for seats
	private int availbleFamilySeats = 0;
	private int TicketsToSell;

	public AirLinesSeating() //constructor
	{
		
		input = new Scanner(System.in);// scanner
		alphabet = new HashMap<String, Integer>();// to store alpha as key
		setAlphabet(alphabet); //set alpha letters to hashmap
		// need to input the seats via a string comma separated.
		System.out.println("Enter the booked seats:  (please separate by commas.)"); // print on console
		String userInput = input.next();// take user input
		String[] seatNumbers = userInput.split(","); //split userinput by comma 
		boolean isCorrectSeatNo = true; //if the userinput was correct format then set to true
		// Included regex to validate user input to make sure the first character is
		// alphabet followed by digits which are between 1 and 10
		Pattern pattern = Pattern.compile("^[a-zA-Z]{1}(?:[1-9]|0[1-9]|10)$"); // regex 
		for (String s : seatNumbers) { 
			Matcher matcher = pattern.matcher(s);
			if (!matcher.matches())
				isCorrectSeatNo = false;
		}
		if (isCorrectSeatNo)
			setBookedSeatNumbers(userInput); // user input
		else {
			System.out.println("Invalid Seat Numbers");
			System.exit(0);
		}
	}
	//Setter
	public void setBookedSeatNumbers(String bookedSeatNumbers) {
		this.bookedSeatNumbers = bookedSeatNumbers;
		setPlaneSeats(bookedSeatNumbers);
	}

//	public String getBookedSeatNumbers() {
//		return bookedSeatNumbers;
//	}

//	public HashMap<String, Integer> getAlphabet() {
//		return alphabet;
//	}
	//Setter
	public void setAlphabet(HashMap<String, Integer> alphabet) {
		setAlphaAsKey(alphabet);
		this.alphabet = alphabet;
	}

//	public String[][] getPlaneSeats() {
//		return planeSeats;
//	}
	//method which takes user string input and changes to array indexes
	public void setPlaneSeats(String bookedSeatNumbers) {
		String bookedArr[] = bookedSeatNumbers.split(","); // split user input to array

		
		// if we want to print will need a for loop.
		// to change each char into integers and store it to plane seats position
		for (int i = 0; i < bookedArr.length; i++) {
			char x = bookedArr[i].charAt(0);
			char y = bookedArr[i].charAt(1);

			int zz = 0;
			//if we have 3rd character logic
			if (bookedArr[i].length() == 3 && bookedArr[i].charAt(2) == 48) {
				char z = bookedArr[i].charAt(2);
				zz = Character.getNumericValue(z + 9);
			}

			String xx = Character.toString(x);
			int yy = Character.getNumericValue(y);

			planeSeats[alphabet.get(xx.toUpperCase())][(yy + zz) - 1] = bookedArr[i];
			
		}

		printPlaneSeating(planeSeats);
	}
	
	public void setAlphaAsKey(HashMap<String, Integer> alphabet) {
		// airplane representation is 26 row a-z and column seats 10 (1-10)
		alphabet.put("A", 0);
		alphabet.put("B", 1);
		alphabet.put("C", 2);
		alphabet.put("D", 3);
		alphabet.put("E", 4);
		alphabet.put("F", 5);
		alphabet.put("G", 6);
		alphabet.put("H", 7);
		alphabet.put("I", 8);
		alphabet.put("J", 9);
		alphabet.put("K", 10);
		alphabet.put("L", 11);
		alphabet.put("M", 12);
		alphabet.put("N", 13);
		alphabet.put("O", 14);
		alphabet.put("P", 15);
		alphabet.put("Q", 16);
		alphabet.put("R", 17);
		alphabet.put("S", 18);
		alphabet.put("T", 19);
		alphabet.put("U", 20);
		alphabet.put("V", 21);
		alphabet.put("W", 22);
		alphabet.put("X", 23);
		alphabet.put("Y", 24);
		alphabet.put("Z", 25);
	}
	//Getter
	public int getAvailableFamilySeats() {
		return this.availbleFamilySeats = findFamilySeating();
	}
	//Method to display airplane seating arrangement
	public void printPlaneSeating(String[][] planeSeats) {
		// print out the seats visually
		for (int rr = 0; rr < 26; rr++) {
			for (int cc = 0; cc < 10; cc++) {
				if (planeSeats[rr][cc] != null)
					System.out.print(planeSeats[rr][cc]);
				else
					System.out.print("_" + " ");
				if (cc == 2 || cc == 6)
					System.out.print("      ");
				else
					System.out.print(" ");
			}
			System.out.println();
		}
	}
	//method to check how many family's can book
	public int findFamilySeating() {

		// check if empty
		// looping through the rows
		// check if seats are available
		for (int i = 0; i < 26; i++) {

			if (planeSeats[i][0] == null && planeSeats[i][1] == null && planeSeats[i][2] == null)
				availbleFamilySeats++; // check to see if seats 1-3 are empty.
			if (planeSeats[i][7] == null && planeSeats[i][8] == null && planeSeats[i][9] == null)
				availbleFamilySeats++; // check to see if seats 8-10 are empty.
			if ((planeSeats[i][3] == null && planeSeats[i][4] == null && planeSeats[i][5] == null)
					|| (planeSeats[i][4] == null && planeSeats[i][5] == null && planeSeats[i][6] == null))
				availbleFamilySeats++;// check to see if 3 seats together in the middle section are empty.
		}
		System.out.println();

		input.close();
		TicketsToSell=availbleFamilySeats;
		return availbleFamilySeats;
		
	}
	public int getTicketsToSell() {
		return TicketsToSell;
	}
	public void setTicketsToSell(int ticketsToSell) {
		TicketsToSell = ticketsToSell;
	}
	

}

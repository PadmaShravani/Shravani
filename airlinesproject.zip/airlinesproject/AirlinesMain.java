package airlinesproject;
/*Scenario:
1) A plane has 26 rows labeled from A to Z and 10 columns labeled from 1 to 10.
2) There are two aisles on the plane. The first aisle is after 3rd column and the second aisle is after 7th column.
3) Families having 3 members wants to seat together in adjacent seats but not separated by an aisle.
4) Some seats are already booked i.e. A4, A10, C5, D3, E6, F8.

Input:
Take already booked seat numbers as String (comma - separated) from the keyboard.

Output
The number of families who can seat together having the restriction mentioned in point 3.
As an example, output 10 means the airline company still can sell 30 tickets following the restriction.
*/
public class AirlinesMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//creating object of a constructor and calling 
		AirLinesSeating a = new AirLinesSeating();
		System.out.println("The number of family groups available: " + a.getAvailableFamilySeats()); // print how many families of 3 people avaliable to book		
		System.out.println("Airline company still can sell "+a.getTicketsToSell()*3+" tickets");
	}

}

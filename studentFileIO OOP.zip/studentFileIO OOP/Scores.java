package assignment;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/* input:file.txt---->1 ss 90 80 100(Id name e1 e2 e3)
 * student id name e1score e2score e3score
 * output:result.txt---->ss 90(name average)
 */
public class Scores {

		public List<Student> getStudents() {
		String location = "C:\\Users\\Student\\eclipse-workspace\\SchoolManagementAssignment\\src\\assignment\\File.txt";
		File f = new File(location);
		Scanner input = null;
		try {
			input = new Scanner(f);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ArrayList<Student> data = new ArrayList<Student>();
		while (input.hasNextLine()) {
			String[] line = input.nextLine().split(",");
			Student stu=new Student();
			stu.setId(Integer.parseInt(line[0]));
			stu.setName(line[1]);
			stu.setE1(Integer.parseInt(line[2]));
			stu.setE2(Integer.parseInt(line[3]));
			stu.setE3(Integer.parseInt(line[4]));
			data.add(stu);
		}
		return data;
	}

}

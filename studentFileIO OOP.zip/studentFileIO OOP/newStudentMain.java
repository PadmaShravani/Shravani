package assignment;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;

public class newStudentMain {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scores scores = new Scores();
		List<Student> students = null;
		Scanner in = new Scanner(System.in);
		int option;
		do {
			System.out.println("Enter an option "+"\n1-Add new Students" + "\n2-to caliculate average" + "\n3-change any score"+"\n4-quit");
			option = in.nextInt();
		switch (option) {
		case 1:
			int id1,s1,s2,s3;
			String name1;
			System.out.println("Enter how many students do you want to add");
			int stu=in.nextInt();
			for(int i=1;i<=stu;i++) {
			System.out.println("Enter id,name and three scores of student "+i);
			id1=in.nextInt();
			name1=in.next();
			s1=in.nextInt();
			s2=in.nextInt();
			s3=in.nextInt();
			
			String location2="C:\\Users\\Student\\eclipse-workspace\\SchoolManagementAssignment\\src\\assignment\\File.txt";
			File file2=new File(location2);
			try {
			FileWriter wr=new FileWriter(file2,true);	
			
				wr.write(String.format("%d,%s,%d,%d,%d\n",id1,name1,s1,s2,s3));
				System.out.println("Entered new student details");
				wr.close();
			
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
			break;
			
		case 2:
			try {
				students = scores.getStudents();
				// System.out.println(students);
				// printing students name and average score
				for (Student st : students) {
					System.out.print("Name- " + st.getName() + " Average score: " + st.average());
					System.out.println();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			String location = "C:\\Users\\Student\\eclipse-workspace\\SchoolManagementAssignment\\src\\assignment\\AverageScore.txt";
			File file = new File(location);
			try {
				FileWriter writer = new FileWriter(file, false);
				for (Student st : students) {
					writer.write(String.format("%s,%s\n", st.getName(), st.average()));
				}
				writer.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			break;
		case 3:
			students = scores.getStudents();
			System.out.println("To change score please enter Id");
			int idEntered = in.nextInt();
			System.out.println("what exam score do u want to change(1,2,3)");
			int examnum = in.nextInt();
			System.out.println("Enter the new score");
			int newscore = in.nextInt();
			for (Student st : students) {
				if (idEntered == st.getId()) {
					if (examnum == 1) {
						st.setE1(newscore);
					} else if (examnum == 2) {
						st.setE2(newscore);
					} else if (examnum == 3) {
						st.setE3(newscore);
					}
				}

			}

			String location1 = "C:\\Users\\Student\\eclipse-workspace\\SchoolManagementAssignment\\src\\assignment\\File.txt";
			File file1 = new File(location1);
			try {
				FileWriter writer = new FileWriter(file1, false);

				for (Student st : students) {
					writer.write(String.format("%d,%s,%d,%d,%d\n", st.getId(), st.getName(), st.getE1(), st.getE2(),
							st.getE3()));
				}
				writer.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		}
		//System.out.println("Enter any option");
		
		}while(option!=4);
		//option=in.nextInt();
		if(option==4) {
			System.out.println("Thank you ");
			//System.exit(0);
		}
	in.close();
	}
}


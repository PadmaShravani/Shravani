package assignment;

public class Student {
	private int id,e1,e2,e3;
	private String name;
	private double average;
	
	public double average() {
		average=(getE1()+getE2()+getE3())/3;
		//System.out.println(average);
		return average;
	}

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(int id,String name,int e1,int e2,int e3) {
		this.id=id;
		this.name=name;
		this.e1=e1;
		this.e2=e2;
		this.e3=e3;
	}

	public Student(int id, int e1, int e2, int e3, String name, double average) {
		super();
		this.id = id;
		this.e1 = e1;
		this.e2 = e2;
		this.e3 = e3;
		this.name = name;
		this.average = average;
	}

	public int getId() {
		return id;
	}

	public int getE1() {
		return e1;
	}

	public int getE2() {
		return e2;
	}

	public int getE3() {
		return e3;
	}

	public String getName() {
		return name;
	}

	
	public void setId(int id) {
		this.id = id;
	}

	public void setE1(int e1) {
		this.e1 = e1;
	}

	public void setE2(int e2) {
		this.e2 = e2;
	}

	public void setE3(int e3) {
		this.e3 = e3;
	}

	public void setName(String name) {
		this.name = name;
	}


	
	
	
}
